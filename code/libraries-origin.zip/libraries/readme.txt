Pour plus d'information sur l'installation des bibliothèques, regardez: http://www.arduino.cc/en/Guide/Libraries
