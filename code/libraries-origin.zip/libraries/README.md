# pnpbox1
basic integrated system for pick and place
