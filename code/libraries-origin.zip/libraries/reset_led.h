#ifndef reset_led_h
#define reset_led_h


// Initializes spindle pins and hardware PWM, if enabled.
void rst_led_init();




#endif
